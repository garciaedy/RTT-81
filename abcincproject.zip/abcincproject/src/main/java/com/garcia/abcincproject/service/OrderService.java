package com.garcia.abcincproject.service;

import java.util.List;
import com.garcia.abcincproject.model.Order;

public class OrderService {
    List<Order> getAllOrders();

}
